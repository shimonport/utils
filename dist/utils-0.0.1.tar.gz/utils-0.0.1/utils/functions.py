def hello():
    print('Hello!')