from utils.functions import hello


hello()