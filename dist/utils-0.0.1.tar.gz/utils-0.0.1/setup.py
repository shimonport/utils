from setuptools import setup

setup(
    name='utils',
    version='0.0.1',
    url='git@github.com:shimonport/utils.git',
    author='Shimon Port',
    packages=['utils'],
    install_requires=['requests']
)